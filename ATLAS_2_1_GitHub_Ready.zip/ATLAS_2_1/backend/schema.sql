PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_key TEXT UNIQUE,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL DEFAULT '1H',
  direction TEXT NOT NULL,
  grade TEXT,
  alignment_count INTEGER,
  ema_confirmed INTEGER DEFAULT 0,
  structural_level REAL,
  candle_close REAL,
  candle_time TEXT,
  price REAL,
  session TEXT,
  setup TEXT,
  source TEXT DEFAULT 'ATLAS',
  raw_json TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_signals_created_at ON signals(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_signals_symbol ON signals(symbol);

CREATE TABLE IF NOT EXISTS scan_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_key TEXT NOT NULL,
  symbol TEXT NOT NULL,
  grade TEXT NOT NULL,
  direction TEXT,
  alignment_count INTEGER NOT NULL DEFAULT 0,
  result_json TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'Twelve Data',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE(run_key, symbol)
);
CREATE INDEX IF NOT EXISTS idx_scan_runs_created ON scan_runs(created_at DESC);

CREATE TABLE IF NOT EXISTS market_candles (
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  candle_time TEXT NOT NULL,
  open REAL NOT NULL,
  high REAL NOT NULL,
  low REAL NOT NULL,
  close REAL NOT NULL,
  volume REAL DEFAULT 0,
  source TEXT NOT NULL,
  PRIMARY KEY(symbol, timeframe, candle_time)
);
CREATE INDEX IF NOT EXISTS idx_market_candles_lookup ON market_candles(symbol, timeframe, candle_time DESC);

CREATE TABLE IF NOT EXISTS scan_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_key TEXT NOT NULL,
  status TEXT NOT NULL,
  detail TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_scan_audit_created ON scan_audit(created_at DESC);
