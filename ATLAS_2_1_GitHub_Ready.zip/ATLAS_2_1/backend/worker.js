import { TIMEFRAMES, validBars, filterClosedBars, aggregateBars, analyzeSymbol, getSastSchedule } from '../strategy-engine.js';

const SYMBOLS = ['XAUUSD', 'XAGUSD', 'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD'];
const DEFAULT_PROVIDER_SYMBOLS = {
  XAUUSD: 'XAU/USD', XAGUSD: 'XAG/USD', EURUSD: 'EUR/USD',
  GBPUSD: 'GBP/USD', USDJPY: 'USD/JPY', AUDUSD: 'AUD/USD'
};
const json = (body, status = 200, extra = {}) => new Response(JSON.stringify(body), {
  status,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra }
});

function corsHeaders(request, env) {
  const origin = request.headers.get('Origin');
  const allowed = env.ALLOWED_ORIGIN || '';
  const headers = { 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Max-Age': '86400', Vary: 'Origin' };
  if (origin && allowed && origin === allowed) headers['Access-Control-Allow-Origin'] = allowed;
  return headers;
}
function secureEqual(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return result === 0;
}
function bearerIsValid(request, env) {
  const auth = request.headers.get('Authorization') || '';
  const supplied = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  return secureEqual(supplied, env.ATLAS_API_TOKEN || '');
}
function cleanString(value, max = 120) { return typeof value === 'string' ? value.trim().slice(0, max) : ''; }
function validWebhookPath(path, env) {
  const prefix = '/tv/';
  return path.startsWith(prefix) && secureEqual(path.slice(prefix.length), env.ATLAS_WEBHOOK_SECRET || '') && path.slice(prefix.length).length >= 24;
}
function timeToIso(value) {
  const text = String(value || '').trim();
  if (!text) return '';
  try {
    // The API request explicitly asks Twelve Data for UTC timestamps.
    const parsed = /Z$|[+-]\d\d:\d\d$/.test(text)
      ? new Date(text)
      : new Date(text.replace(' ', 'T') + 'Z');
    return Number.isFinite(parsed.getTime()) ? parsed.toISOString() : '';
  } catch (_) { return ''; }
}
function providerReady(env) {
  return Boolean(env.TWELVE_DATA_API_KEY)
    && String(env.TWELVE_DATA_DISPLAY_RIGHTS_CONFIRMED || '').toLowerCase() === 'true'
    && String(env.TWELVE_DATA_METALS_ACCESS_CONFIRMED || '').toLowerCase() === 'true';
}
function providerSymbol(symbol, env) {
  const key = `TWELVE_DATA_SYMBOL_${symbol}`;
  return env[key] || DEFAULT_PROVIDER_SYMBOLS[symbol] || symbol;
}
async function fetchTwelveSeries(symbol, interval, outputsize, env) {
  const key = env.TWELVE_DATA_API_KEY;
  if (!key) throw new Error('TWELVE_DATA_API_KEY is not configured.');
  const url = new URL('https://api.twelvedata.com/time_series');
  url.searchParams.set('symbol', providerSymbol(symbol, env));
  url.searchParams.set('interval', interval);
  url.searchParams.set('outputsize', String(outputsize));
  url.searchParams.set('timezone', 'UTC');
  url.searchParams.set('format', 'JSON');
  url.searchParams.set('apikey', key);
  const response = await fetch(url.toString(), { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`Twelve Data HTTP ${response.status} for ${symbol} ${interval}.`);
  const payload = await response.json();
  if (!Array.isArray(payload.values)) throw new Error(cleanString(payload.message || payload.code || 'Provider returned no candle values.', 180));
  return validBars(payload.values.map((v) => ({
    time: timeToIso(v.datetime), open: v.open, high: v.high, low: v.low, close: v.close, volume: v.volume || 0
  })));
}
async function waitForNextMinute() {
  const now = Date.now();
  const wait = 60_000 - (now % 60_000) + 250;
  await new Promise((resolve) => setTimeout(resolve, wait));
}
async function writeNewCandles(env, symbol, timeframe, bars, source) {
  const latest = await env.ATLAS_DB.prepare('SELECT MAX(candle_time) AS latest FROM market_candles WHERE symbol = ? AND timeframe = ?').bind(symbol, timeframe).first();
  const lastTime = latest?.latest || '';
  const fresh = bars.filter((bar) => bar.time > lastTime);
  if (!fresh.length) return 0;
  const statements = fresh.map((bar) => env.ATLAS_DB.prepare(`
    INSERT OR IGNORE INTO market_candles (symbol, timeframe, candle_time, open, high, low, close, volume, source)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(symbol, timeframe, bar.time, bar.open, bar.high, bar.low, bar.close, bar.volume || 0, source));
  for (let i = 0; i < statements.length; i += 80) await env.ATLAS_DB.batch(statements.slice(i, i + 80));
  return fresh.length;
}
async function recordScan(env, runKey, result, source) {
  const raw = JSON.stringify(result).slice(0, 48_000);
  await env.ATLAS_DB.prepare(`INSERT OR IGNORE INTO scan_runs (run_key, symbol, grade, direction, alignment_count, result_json, source)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).bind(runKey, result.symbol, result.grade, result.direction || '', result.alignmentCount || 0, raw, source).run();
  if (result.structuralBreak) {
    const b = result.structuralBreak;
    const eventKey = [result.symbol, b.direction, b.level, b.candleTime].join('|').slice(0, 240);
    await env.ATLAS_DB.prepare(`INSERT OR IGNORE INTO signals
      (event_key, symbol, timeframe, direction, grade, alignment_count, ema_confirmed, structural_level, candle_close, candle_time, price, session, setup, source, raw_json)
      VALUES (?, ?, '1H', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ATLAS', ?)`)
      .bind(eventKey, result.symbol, b.direction, result.grade, result.alignmentCount, result.ema1hConfirmed ? 1 : 0,
        b.level, b.candleClose, b.candleTime, result.price, 'SAST schedule', b.type, raw).run();
  }
}
async function runMarketScan(env, runKey, scheduledAt = new Date()) {
  const schedule = getSastSchedule(scheduledAt);
  if (schedule.condition === 'MAJOR_CLOSURE') {
    await env.ATLAS_DB.prepare('INSERT INTO scan_audit (run_key, status, detail) VALUES (?, ?, ?)')
      .bind(runKey, 'skipped', `Scheduled invocation outside an approved SAST scanning window (${schedule.sast}).`).run();
    return { ok: false, skipped: true, reason: 'outside_scan_window' };
  }
  if (!env.TWELVE_DATA_API_KEY) {
    await env.ATLAS_DB.prepare('INSERT INTO scan_audit (run_key, status, detail) VALUES (?, ?, ?)')
      .bind(runKey, 'skipped', 'Market-data provider key is not configured. No market data was requested.').run();
    return { ok: false, skipped: true, reason: 'provider_not_configured' };
  }
  if (!providerReady(env)) {
    await env.ATLAS_DB.prepare('INSERT INTO scan_audit (run_key, status, detail) VALUES (?, ?, ?)')
      .bind(runKey, 'skipped', 'Market-data display permission and Gold/Silver instrument entitlement have not both been explicitly confirmed. No market data was requested.').run();
    return { ok: false, skipped: true, reason: 'provider_entitlement_not_confirmed' };
  }
  const errors = [], results = [];
  const configuredStrength = Number(env.ATLAS_SWING_STRENGTH || 2);
  const swingStrength = Number.isInteger(configuredStrength) ? Math.max(2, Math.min(5, configuredStrength)) : 2;
  // Twelve Data Basic allows 8 weighted credits/minute. Two symbols (4 requests) per batch leave headroom.
  for (let offset = 0; offset < SYMBOLS.length; offset += 2) {
    const batchSymbols = SYMBOLS.slice(offset, offset + 2);
    const batch = await Promise.all(batchSymbols.map(async (symbol) => {
      try {
        const [intraday, daily] = await Promise.all([
          fetchTwelveSeries(symbol, '30min', 500, env),
          fetchTwelveSeries(symbol, '1day', 180, env)
        ]);
        const scanNow = Date.now();
        const closed30 = filterClosedBars(intraday, scanNow, 30);
        const closed1d = filterClosedBars(daily, scanNow, 1440);
        const latest30ClosedAt = closed30.length ? Date.parse(closed30.at(-1).time) + 30 * 60_000 : NaN;
        const latestDailyClosedAt = closed1d.length ? Date.parse(closed1d.at(-1).time) + 1440 * 60_000 : NaN;
        if (!Number.isFinite(latest30ClosedAt) || scanNow - latest30ClosedAt > 90 * 60_000) {
          throw new Error('Latest completed 30M candle is missing or stale (older than 90 minutes).');
        }
        if (!Number.isFinite(latestDailyClosedAt) || scanNow - latestDailyClosedAt > 72 * 60 * 60_000) {
          throw new Error('Latest completed daily candle is missing or stale (older than 72 hours).');
        }
        await writeNewCandles(env, symbol, '30M', closed30, 'Twelve Data');
        await writeNewCandles(env, symbol, '1D', closed1d, 'Twelve Data');
        const datasets = {
          '30M': closed30,
          '1H': aggregateBars(closed30, 60, Date.now(), 30),
          '2H': aggregateBars(closed30, 120, Date.now(), 30),
          '4H': aggregateBars(closed30, 240, Date.now(), 30),
          '1D': closed1d
        };
        const result = analyzeSymbol(symbol, datasets, { swingStrength, dataMode: 'Twelve Data' });
        if (!result.ready) throw new Error(`Insufficient complete candles for all five timeframes (${Object.entries(result.frames).map(([tf, x]) => `${tf}:${x.bars}`).join(', ')}).`);
        return result;
      } catch (error) {
        errors.push({ symbol, error: cleanString(error.message || 'Unknown provider error', 240) });
        return null;
      }
    }));
    results.push(...batch.filter(Boolean));
    if (offset + 2 < SYMBOLS.length) await waitForNextMinute();
  }
  for (const result of results) await recordScan(env, runKey, result, 'Twelve Data');
  // Keep only a compact rolling history. Unique candle keys prevent repeated scan writes.
  await env.ATLAS_DB.prepare(`DELETE FROM market_candles WHERE julianday(candle_time) < julianday('now', '-180 days')`).run();
  await env.ATLAS_DB.prepare(`DELETE FROM scan_runs WHERE id NOT IN (SELECT id FROM scan_runs ORDER BY id DESC LIMIT 1000)`).run();
  await env.ATLAS_DB.prepare(`DELETE FROM signals WHERE id NOT IN (SELECT id FROM signals ORDER BY id DESC LIMIT 1000)`).run();
  await env.ATLAS_DB.prepare(`DELETE FROM scan_audit WHERE id NOT IN (SELECT id FROM scan_audit ORDER BY id DESC LIMIT 1000)`).run();
  const status = results.length ? (errors.length ? 'partial' : 'completed') : 'failed';
  await env.ATLAS_DB.prepare('INSERT INTO scan_audit (run_key, status, detail) VALUES (?, ?, ?)')
    .bind(runKey, status, `${results.length}/${SYMBOLS.length} symbols analysed; ${errors.length} errors. ${errors.map((x) => `${x.symbol}: ${x.error}`).join(' | ')}`.slice(0, 1500)).run();
  return { ok: results.length > 0, runKey, analysed: results.length, errors, results };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = corsHeaders(request, env);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    if (url.pathname === '/api/health' && request.method === 'GET') {
      let database = 'unavailable';
      try { await env.ATLAS_DB.prepare('SELECT 1 AS ok').first(); database = 'connected'; } catch (_) { /* Avoid leaking DB details */ }
      const ok = database === 'connected';
      return json({ ok, service: 'ATLAS 2.1 intelligence worker', version: '2.1.0', database,
        marketDataProvider: env.TWELVE_DATA_API_KEY ? 'key_configured' : 'not_configured',
        marketDataEnabled: providerReady(env),
        marketDataBlockReason: !env.TWELVE_DATA_API_KEY ? 'api_key_missing' : !providerReady(env) ? 'display_or_metals_entitlement_not_confirmed' : null,
        scheduledScanning: true, scanSchedule: 'Weekdays, SAST 08:00–20:00 using the fixed 2h/90m/1h windows', tradeExecution: false }, ok ? 200 : 503, cors);
    }

    if (url.pathname.startsWith('/tv/') && request.method === 'POST') {
      if (!validWebhookPath(url.pathname, env)) return json({ error: 'Not found' }, 404, cors);
      let rawBody, body;
      try {
        rawBody = await request.text();
        if (new TextEncoder().encode(rawBody).byteLength > 16_000) return json({ error: 'Payload too large' }, 413, cors);
        body = JSON.parse(rawBody);
      } catch (_) { return json({ error: 'Expected a JSON body' }, 400, cors); }
      if (!body || typeof body !== 'object' || Array.isArray(body)) return json({ error: 'Webhook payload must be a JSON object.' }, 400, cors);
      const symbol = cleanString(body.symbol || body.ticker, 24).toUpperCase();
      const direction = cleanString(body.direction || body.side, 12).toUpperCase();
      const timeframeRaw = cleanString(body.timeframe || body.tf || '1H', 8).toUpperCase();
      if (!SYMBOLS.includes(symbol) || !['LONG', 'SHORT', 'BUY', 'SELL'].includes(direction) || !['1H', '60'].includes(timeframeRaw)) return json({ error: 'Only supported instruments and confirmed 1H structure events are accepted.' }, 422, cors);
      const normalizedDirection = direction === 'BUY' ? 'LONG' : direction === 'SELL' ? 'SHORT' : direction;
      const grade = cleanString(body.grade, 4).toUpperCase();
      const eventKey = cleanString(body.event_key || `${symbol}|${normalizedDirection}|${body.candle_time || body.time || Date.now()}`, 240);
      try {
        await env.ATLAS_DB.prepare(`INSERT OR IGNORE INTO signals (event_key, symbol, timeframe, direction, grade, alignment_count, ema_confirmed, structural_level, candle_close, candle_time, price, session, setup, source, raw_json)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'TradingView', ?)`)
          .bind(eventKey, symbol, '1H', normalizedDirection,
            ['A++','A+','A','B+','B','C+','C'].includes(grade) ? grade : null, Number(body.alignment_count || 0), body.ema_confirmed ? 1 : 0,
            Number.isFinite(Number(body.structural_level)) ? Number(body.structural_level) : null,
            Number.isFinite(Number(body.candle_close)) ? Number(body.candle_close) : null,
            cleanString(body.candle_time || body.time, 40), Number.isFinite(Number(body.price)) ? Number(body.price) : null,
            cleanString(body.session, 40), cleanString(body.setup || 'External candidate', 120), JSON.stringify(body).slice(0, 12000)).run();
        return json({ ok: true, accepted: true }, 201, cors);
      } catch (_) { return json({ error: 'Signal could not be stored. Check the D1 schema.' }, 500, cors); }
    }

    if (url.pathname === '/api/candles' && request.method === 'GET') {
      if (!bearerIsValid(request, env)) return json({ error: 'Unauthorised' }, 401, cors);
      const symbol = cleanString(url.searchParams.get('symbol'), 12).toUpperCase();
      const timeframe = cleanString(url.searchParams.get('timeframe'), 4).toUpperCase();
      if (!SYMBOLS.includes(symbol) || !['30M', '1D'].includes(timeframe)) {
        return json({ error: 'Request a supported instrument and stored timeframe (30M or 1D).' }, 422, cors);
      }
      const requested = Number(url.searchParams.get('limit') || (timeframe === '30M' ? 500 : 180));
      const limit = Math.max(1, Math.min(timeframe === '30M' ? 500 : 180, Number.isFinite(requested) ? requested : 100));
      try {
        const { results = [] } = await env.ATLAS_DB.prepare(`SELECT candle_time AS time, open, high, low, close, volume, source
          FROM market_candles WHERE symbol = ? AND timeframe = ? ORDER BY candle_time DESC LIMIT ?`)
          .bind(symbol, timeframe, limit).all();
        return json({ symbol, timeframe, candles: results.reverse(), count: results.length,
          dataStatus: 'stored-provider-data', source: results.at(-1)?.source || 'unknown source', latest: results.at(-1)?.time || null }, 200, cors);
      } catch (_) { return json({ error: 'Candle history query failed' }, 500, cors); }
    }

    if (url.pathname === '/api/signals' && request.method === 'GET') {
      if (!bearerIsValid(request, env)) return json({ error: 'Unauthorised' }, 401, cors);
      const requested = Number(url.searchParams.get('limit') || 50);
      const limit = Math.max(1, Math.min(100, Number.isFinite(requested) ? requested : 50));
      try {
        const { results = [] } = await env.ATLAS_DB.prepare(`SELECT id, event_key, symbol, timeframe, direction, grade, alignment_count, ema_confirmed,
          structural_level, candle_close, candle_time, price, session, setup, source, created_at FROM signals ORDER BY id DESC LIMIT ?`).bind(limit).all();
        return json({ signals: results }, 200, cors);
      } catch (_) { return json({ error: 'Signals database query failed' }, 500, cors); }
    }

    if (url.pathname === '/api/scans' && request.method === 'GET') {
      if (!bearerIsValid(request, env)) return json({ error: 'Unauthorised' }, 401, cors);
      const requested = Number(url.searchParams.get('limit') || 30);
      const limit = Math.max(1, Math.min(60, Number.isFinite(requested) ? requested : 30));
      try {
        const { results = [] } = await env.ATLAS_DB.prepare(`SELECT run_key, symbol, grade, direction, alignment_count, result_json, source, created_at
          FROM scan_runs ORDER BY id DESC LIMIT ?`).bind(limit).all();
        return json({ scans: results.map((row) => ({ ...row, result: JSON.parse(row.result_json) })) }, 200, cors);
      } catch (_) { return json({ error: 'Scan history query failed' }, 500, cors); }
    }

    if (url.pathname === '/api/scan' && request.method === 'POST') {
      if (!bearerIsValid(request, env)) return json({ error: 'Unauthorised' }, 401, cors);
      const result = await runMarketScan(env, `manual-${Date.now()}`, new Date());
      return json(result, result.ok ? 200 : result.skipped ? 409 : 503, cors);
    }

    if (url.pathname === '/api/audit' && request.method === 'GET') {
      if (!bearerIsValid(request, env)) return json({ error: 'Unauthorised' }, 401, cors);
      const { results = [] } = await env.ATLAS_DB.prepare(`SELECT run_key, status, detail, created_at FROM scan_audit ORDER BY id DESC LIMIT 30`).all();
      return json({ audit: results }, 200, cors);
    }

    return json({ error: 'Not found' }, 404, cors);
  },

  async scheduled(event, env, ctx) {
    const at = new Date(event.scheduledTime || Date.now());
    const schedule = getSastSchedule(at);
    const runKey = `cron-${at.toISOString()}`;
    if (schedule.condition === 'MAJOR_CLOSURE') {
      ctx.waitUntil(env.ATLAS_DB.prepare('INSERT INTO scan_audit (run_key, status, detail) VALUES (?, ?, ?)')
        .bind(runKey, 'skipped', `No scan in the ${schedule.label.toLowerCase()} window.`).run());
      return;
    }
    ctx.waitUntil(runMarketScan(env, runKey, at));
  }
};
