import test from 'node:test';
import assert from 'node:assert/strict';
import {
  TIMEFRAMES, EMA_PERIOD, ema, validBars, filterClosedBars, aggregateBars,
  detectSwings, describeTrend, findLatestConfirmedBreak, gradeSetup, analyzeSymbol,
  getSastSchedule
} from '../strategy-engine.js';

function makeBars(closes, start = '2026-11-09T00:00:00.000Z', minutes = 60) {
  const base = Date.parse(start);
  return closes.map((close, i) => ({
    time: new Date(base + i * minutes * 60_000).toISOString(),
    open: close, high: close + 0.05, low: close - 0.05, close, volume: 1
  }));
}

test('only the five approved timeframes are exposed', () => {
  assert.deepEqual(TIMEFRAMES.map((x) => x.id), ['1D', '4H', '2H', '1H', '30M']);
  assert.equal(EMA_PERIOD, 50);
});

test('EMA is a 50-period close series with no premature values', () => {
  const values = Array.from({ length: 60 }, (_, i) => 100 + i);
  const result = ema(values, 50);
  assert.equal(result.length, 60);
  assert.equal(result.slice(0, 49).every((x) => x === null), true);
  assert.equal(Number.isFinite(result[49]), true);
  assert.equal(Number.isFinite(result[59]), true);
});

test('validBars rejects invalid timestamps and duplicate candle times', () => {
  const source = makeBars([1, 2]);
  const rows = validBars([...source, { ...source[0], close: 50, open: 50, high: 50.1, low: 49.9 }, { time: 'not-a-date', open: 1, high: 2, low: 0, close: 1 }]);
  assert.equal(rows.length, 2);
  assert.equal(rows[0].close, 1);
});

test('only fully closed candles are passed to analysis', () => {
  const bars = makeBars([1, 2], '2026-11-09T00:00:00.000Z', 30);
  const now = Date.parse('2026-11-09T01:00:00.000Z');
  assert.deepEqual(filterClosedBars(bars, now, 30).map((x) => x.close), [1, 2]);
  assert.deepEqual(filterClosedBars(bars, Date.parse('2026-11-09T00:45:00.000Z'), 30).map((x) => x.close), [1]);
});

test('higher timeframe aggregation discards incomplete buckets', () => {
  const bars = makeBars([10, 11, 12, 13, 14], '2026-11-09T00:00:00.000Z', 30);
  const aggregated = aggregateBars(bars, 60, Date.parse('2026-11-09T04:00:00.000Z'), 30);
  assert.equal(aggregated.length, 2);
  assert.deepEqual(aggregated.map((x) => x.close), [11, 13]);
  assert.equal(aggregated[0].open, 10);
  assert.equal(aggregated[0].high, 11.05);
  assert.equal(aggregated[0].low, 9.95);
});

test('line-chart pivots are based on closing prices and need right-side confirmation', () => {
  const bars = makeBars([1, 2, 4, 2, 1, 2, 5, 2, 0, 1, 3, 1, -1]);
  const swings = detectSwings(bars, 2);
  assert.ok(swings.highs.some((x) => x.index === 2 && x.price === 4));
  assert.ok(swings.highs.some((x) => x.index === 6 && x.price === 5));
  assert.ok(swings.lows.some((x) => x.index === 4 && x.price === 1));
  // The last two bars cannot be confirmed as pivots because right-side bars are missing.
  assert.equal(swings.highs.some((x) => x.index === 11), false);
  assert.equal(swings.lows.some((x) => x.index === 12), false);
});

test('trend direction requires HH+HL or LH+LL close-based swing structure', () => {
  assert.equal(describeTrend({ highs: [{ price: 4 }, { price: 5 }], lows: [{ price: 1 }, { price: 2 }] }), 'BULLISH');
  assert.equal(describeTrend({ highs: [{ price: 5 }, { price: 4 }], lows: [{ price: 2 }, { price: 1 }] }), 'BEARISH');
  assert.equal(describeTrend({ highs: [{ price: 4 }, { price: 5 }], lows: [{ price: 2 }, { price: 1 }] }), 'NEUTRAL');
});

test('a bullish break is detected only when a completed candle closes above the confirmed swing level', () => {
  const bars = makeBars([2, 3, 5, 4, 3, 2.5, 3, 2.8, 2.6, 3, 4, 5.2]);
  const event = findLatestConfirmedBreak(bars, 2, 3);
  assert.ok(event);
  assert.equal(event.direction, 'LONG');
  assert.equal(event.level, 5);
  assert.equal(event.candleClose, 5.2);
  assert.equal(event.confirmation, 'CLOSED_CANDLE_ABOVE_LEVEL');
});

test('A++ requires the strict five-frame structure plus 1H EMA; non-1H EMA cannot upgrade', () => {
  assert.equal(gradeSetup(5, true, false), 'A+');
  assert.equal(gradeSetup(5, true, true), 'A++');
  assert.equal(gradeSetup(5, false, true), 'B+');
  assert.equal(gradeSetup(4, true, true), 'A');
  assert.equal(gradeSetup(3, true, false), 'B+');
  assert.equal(gradeSetup(2, true, false), 'C+');
  assert.equal(gradeSetup(1, false, false), 'C');
});

test('SAST scan timetable follows the approved weekday windows', () => {
  const at = (utc) => getSastSchedule(new Date(utc));
  assert.equal(at('2026-11-09T06:00:00.000Z').condition, 'QUIET'); // 08:00 SAST
  assert.equal(at('2026-11-09T06:00:00.000Z').frequencyMinutes, 120);
  assert.equal(at('2026-11-09T08:00:00.000Z').condition, 'NORMAL'); // 10:00 SAST
  assert.equal(at('2026-11-09T08:00:00.000Z').frequencyMinutes, 90);
  assert.equal(at('2026-11-09T09:30:00.000Z').condition, 'NORMAL'); // 11:30 SAST
  assert.equal(at('2026-11-09T10:00:00.000Z').condition, 'HIGH'); // 12:00 SAST
  assert.equal(at('2026-11-09T10:00:00.000Z').frequencyMinutes, 60);
  assert.equal(at('2026-11-09T18:00:00.000Z').condition, 'MAJOR_CLOSURE'); // 20:00 SAST
  assert.equal(at('2026-11-07T10:00:00.000Z').condition, 'MAJOR_CLOSURE'); // Saturday
});

test('a bearish break is detected from a completed candle close below the confirmed line-chart swing low', () => {
  const bars = makeBars([5, 4, 2, 3, 4, 4.5, 4, 4.2, 4.4, 4, 3, 1.8]);
  const event = findLatestConfirmedBreak(bars, 2, 3);
  assert.ok(event);
  assert.equal(event.direction, 'SHORT');
  assert.equal(event.level, 2);
  assert.equal(event.candleClose, 1.8);
  assert.equal(event.confirmation, 'CLOSED_CANDLE_BELOW_LEVEL');
});

test('an intrabar wick beyond structure without a close beyond the level is not a breakout', () => {
  const bars = makeBars([2, 3, 5, 4, 3, 2.5, 3, 2.8, 2.6, 3, 4, 4.8]);
  bars.at(-1).open = 4.9;
  bars.at(-1).high = 5.6;
  bars.at(-1).low = 4.7;
  bars.at(-1).close = 4.8;
  assert.equal(findLatestConfirmedBreak(bars, 2, 3), null);
});


function risingStructureBars(start, minutes, includeBreak = false) {
  const closes = [];
  let base = 100;
  for (let cycle = 0; cycle < 10; cycle++) {
    closes.push(base, base + 1, base + 4, base + 2, base + 1, base + 3);
    base += 2;
  }
  if (includeBreak) closes.push(base + 3);
  const startMs = Date.parse(start);
  return closes.map((close, index) => ({
    time: new Date(startMs + index * minutes * 60_000).toISOString(),
    open: close, high: close + 0.05, low: close - 0.05, close
  }));
}

function fallingStructureBars(start, minutes) {
  const closes = [];
  let base = 200;
  for (let cycle = 0; cycle < 10; cycle++) {
    closes.push(base, base - 1, base - 4, base - 2, base - 1, base - 3);
    base -= 2;
  }
  const startMs = Date.parse(start);
  return closes.map((close, index) => ({
    time: new Date(startMs + index * minutes * 60_000).toISOString(),
    open: close, high: close + 0.05, low: close - 0.05, close
  }));
}

test('full strategy gives A++ only when all five timeframes align and the 1H EMA confirms', () => {
  const start = '2025-01-01T00:00:00.000Z';
  const datasets = {
    '1D': risingStructureBars(start, 1440),
    '4H': risingStructureBars(start, 240),
    '2H': risingStructureBars(start, 120),
    '1H': risingStructureBars(start, 60, true),
    '30M': risingStructureBars(start, 30)
  };
  const aligned = analyzeSymbol('XAUUSD', datasets);
  assert.equal(aligned.alignmentCount, 5);
  assert.equal(aligned.grade, 'A++');
  assert.equal(aligned.structuralBreak.confirmation, 'CLOSED_CANDLE_ABOVE_LEVEL');

  const misaligned = analyzeSymbol('XAUUSD', { ...datasets, '30M': fallingStructureBars(start, 30) });
  assert.equal(misaligned.alignmentCount, 4);
  assert.equal(misaligned.grade, 'A');
});
