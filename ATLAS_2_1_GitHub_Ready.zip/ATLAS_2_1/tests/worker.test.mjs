import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../backend/worker.js';

function makeDb() {
  const calls = [];
  return {
    calls,
    prepare(sql) {
      return {
        sql,
        values: [],
        bind(...values) { this.values = values; return this; },
        async first() { calls.push({ type: 'first', sql, values: this.values }); return { ok: 1, latest: null }; },
        async all() { calls.push({ type: 'all', sql, values: this.values }); return { results: [] }; },
        async run() { calls.push({ type: 'run', sql, values: this.values }); return { success: true }; }
      };
    },
    async batch(statements) { calls.push({ type: 'batch', count: statements.length }); return []; }
  };
}

const envFor = (overrides = {}) => ({
  ATLAS_DB: makeDb(),
  ATLAS_API_TOKEN: 'test-api-token-long-enough',
  ATLAS_WEBHOOK_SECRET: 'test-webhook-secret-that-is-long-enough',
  ALLOWED_ORIGIN: 'https://example.github.io',
  ...overrides
});

const request = (path, options = {}) => new Request(`https://atlas.example.workers.dev${path}`, options);

 test('health endpoint reports database status and keeps provider disabled by default', async () => {
  const env = envFor();
  const response = await worker.fetch(request('/api/health'), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.database, 'connected');
  assert.equal(body.marketDataEnabled, false);
  assert.equal(body.marketDataBlockReason, 'api_key_missing');
  assert.equal(body.tradeExecution, false);
});

test('private signals endpoint rejects an absent bearer token', async () => {
  const response = await worker.fetch(request('/api/signals'), envFor());
  assert.equal(response.status, 401);
});

test('private candle endpoint accepts token and returns only an approved stored timeframe', async () => {
  const env = envFor();
  const response = await worker.fetch(request('/api/candles?symbol=XAUUSD&timeframe=30M', {
    headers: { Authorization: `Bearer ${env.ATLAS_API_TOKEN}` }
  }), env);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.timeframe, '30M');
  assert.deepEqual(body.candles, []);
});

test('candle endpoint rejects removed timeframes', async () => {
  const env = envFor();
  const response = await worker.fetch(request('/api/candles?symbol=XAUUSD&timeframe=15M', {
    headers: { Authorization: `Bearer ${env.ATLAS_API_TOKEN}` }
  }), env);
  assert.equal(response.status, 422);
});

test('CORS only reflects the explicitly allowed origin', async () => {
  const env = envFor();
  const allowed = await worker.fetch(request('/api/health', { headers: { Origin: 'https://example.github.io' } }), env);
  const blocked = await worker.fetch(request('/api/health', { headers: { Origin: 'https://attacker.example' } }), env);
  assert.equal(allowed.headers.get('Access-Control-Allow-Origin'), 'https://example.github.io');
  assert.equal(blocked.headers.get('Access-Control-Allow-Origin'), null);
});

test('webhook route rejects an incorrect secret and accepts a valid event payload', async () => {
  const env = envFor();
  const denied = await worker.fetch(request('/tv/incorrect-secret-long-enough-to-pass-minimum', { method: 'POST', body: '{}' }), env);
  assert.equal(denied.status, 404);
  const accepted = await worker.fetch(request(`/tv/${env.ATLAS_WEBHOOK_SECRET}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symbol: 'XAUUSD', timeframe: '1H', direction: 'LONG', structural_level: 2000, candle_close: 2001, candle_time: '2026-11-09T10:00:00Z', event_key: 'test-event-1' })
  }), env);
  assert.equal(accepted.status, 201);
  assert.equal(env.ATLAS_DB.calls.some(x => x.type === 'run' && x.sql.includes('INSERT OR IGNORE INTO signals')), true);
});

test('webhook accepts only 1H events, preserving the personal entry timeframe', async () => {
  const env = envFor();
  const response = await worker.fetch(request(`/tv/${env.ATLAS_WEBHOOK_SECRET}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symbol: 'XAUUSD', timeframe: '30M', direction: 'LONG' })
  }), env);
  assert.equal(response.status, 422);
});

test('webhook rejects oversized payloads even without a Content-Length header', async () => {
  const env = envFor();
  const response = await worker.fetch(request(`/tv/${env.ATLAS_WEBHOOK_SECRET}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symbol: 'XAUUSD', timeframe: '1H', direction: 'LONG', padding: 'x'.repeat(17_000) })
  }), env);
  assert.equal(response.status, 413);
});

test('scheduled weekend invocation is audited without fetching market data', async () => {
  const env = envFor({ TWELVE_DATA_API_KEY: 'must-not-be-used' });
  const waiting = [];
  await worker.scheduled(
    { scheduledTime: Date.parse('2026-11-08T06:00:00.000Z') },
    env,
    { waitUntil(promise) { waiting.push(promise); } }
  );
  await Promise.all(waiting);
  assert.equal(env.ATLAS_DB.calls.some(x => x.type === 'run' && x.sql.includes('INSERT INTO scan_audit')), true);
  assert.equal(env.ATLAS_DB.calls.some(x => x.type === 'run' && x.sql.includes('INSERT INTO market_candles')), false);
});
