import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const app = readFileSync(new URL('../app.js', import.meta.url), 'utf8');
const worker = readFileSync(new URL('../backend/worker.js', import.meta.url), 'utf8');
const config = readFileSync(new URL('../backend/wrangler.toml', import.meta.url), 'utf8');

function optionValues(id) {
  const match = html.match(new RegExp(`<select[^>]*id="${id}"[^>]*>([\\s\\S]*?)<\\/select>`, 'i'));
  assert.ok(match, `Expected select #${id}`);
  return [...match[1].matchAll(/<option(?:[^>]*value="([^"]*)")?[^>]*>([\s\S]*?)<\/option>/gi)]
    .map(m => (m[1] || m[2].replace(/<[^>]+>/g, '').trim()));
}

test('chart and CSV controls expose only the five approved timeframes', () => {
  assert.deepEqual(optionValues('chartTimeframe'), ['1D', '4H', '2H', '1H', '30M']);
  assert.deepEqual(optionValues('csvTimeframe'), ['30M', '1H', '2H', '4H', '1D']);
});

test('the page has unique IDs and all direct app ID selectors resolve', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, new Set(ids).size, 'HTML IDs must be unique');
  const refs = new Set([...app.matchAll(/\$\('#([A-Za-z][\w-]*)'\)/g)].map(m => m[1]));
  const absent = [...refs].filter(id => !ids.includes(id));
  assert.deepEqual(absent, []);
});

test('chart defaults to line view and shows no fabricated prices', () => {
  assert.match(app, /chartMode:'line'/);
  assert.match(app, /No verified candles available/);
  assert.doesNotMatch(app, /generateDemoBars|syntheticCandles|createMockPrices/i);
});

test('cloud Worker schedule is aligned to the fixed SAST weekday scan times', () => {
  assert.match(config, /crons = \["0 6,8,10-17 \* \* 1-5", "30 9 \* \* 1-5"\]/);
  assert.match(worker, /TWELVE_DATA_DISPLAY_RIGHTS_CONFIRMED/);
  assert.match(worker, /TWELVE_DATA_METALS_ACCESS_CONFIRMED/);
});

test('deployment artefacts exist, including hidden Pages workflow and D1 schema', () => {
  assert.equal(existsSync(new URL('../.github/workflows/deploy-pages.yml', import.meta.url)), true);
  assert.equal(existsSync(new URL('../backend/schema.sql', import.meta.url)), true);
  assert.equal(existsSync(new URL('../strategy-engine.js', import.meta.url)), true);
});
