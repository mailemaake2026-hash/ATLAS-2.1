# ATLAS 2.1 — Command Deck — Adaptive Trading & Learning Analytics System

ATLAS 2.1 is a mobile-first personal trading-intelligence workspace for analysing Gold, Silver and selected major Forex pairs. It is designed to assist the user's own decision-making. It does not connect to a broker, place orders or make a final judgement about the quality of a breakout candle.

## Personal strategy implemented

### Markets and sessions

- XAUUSD, XAGUSD, EURUSD, GBPUSD, USDJPY and AUDUSD.
- Primary focus: London and New York sessions.
- All operating schedule times are South African Standard Time (SAST, UTC+2).

### Five approved timeframes only

Daily (1D), 4-hour (4H), 2-hour (2H), 1-hour (1H) and 30-minute (30M). Monthly, weekly, 15-minute and 5-minute intervals are excluded from the strategy engine and CSV importer.

### Market structure and entries

- Line-chart structure is calculated from completed candle closing prices, not wick highs/lows.
- Confirmed pivots use a configurable 2–5 completed-bar left/right strength. The right-side bars must close before a pivot is accepted, which prevents the latest unconfirmed pivot from being treated as historical fact.
- A structural break is reported only after a completed 1H candle closes beyond the previously confirmed close-based swing level. Intrabar touches and temporary moves beyond the level do not qualify.
- The 1H confirmed structural close-break is the user's entry cue. The user personally inspects and validates the breakout candle.
- Head-and-shoulders and inverse head-and-shoulders are examples of patterns the user may recognise; the current engine detects the resulting close-based swing structure and confirmed break, but does not yet classify those named formations as dedicated chart patterns.
- Range/accumulation detection is included as a provisional heuristic: the last 12 1H closes are treated as a compact range when their width is no more than 3.5 times the recent 14-period average true range. This is an implementation starting point, not a threshold supplied or confirmed by the user; change it only after reviewing it with the user.

### Setup classifications

- **A+**: all five approved timeframes align and a confirmed 1H structural close-break is present.
- **A++**: A+ conditions plus the 1H close is above the 1H 50-period EMA for a bullish setup, or below it for a bearish setup.
- EMA confirmation on another timeframe is informative but cannot upgrade A+ to A++ and is never compulsory for A+.
- A, B+, B, C+ and C are provisional lower-confirmation rankings derived from the user's A+ definition. They are not independently user-approved entry rules and must be reviewed against the user's feedback before being treated as trading rules.

## Scheduled scanning timetable

The Cloudflare Worker Cron Triggers are fixed to SAST on weekdays:

| SAST time | User-defined condition | Scheduled full scan |
|---|---|---|
| 08:00–10:00 | Quiet | 08:00 (two-hour window) |
| 10:00–12:00 | Normal | 10:00 and 11:30 |
| 12:00–20:00 | High activity | 12:00 through 19:00, hourly |
| 20:00–08:00 | Major closure | None |
| Saturday and Sunday | No scheduled scan | None |

This is a clock-based schedule based on the user's experience. ATLAS does not connect to a second service to measure volatility. The schedule is not an exchange-hours calendar and does not infer public holidays; it follows the configured weekday/time windows.

## Included application features

- Responsive PWA shell with Android-friendly layout, install metadata and offline application-shell caching.
- Overview, five-timeframe strategy dashboard, opportunity scanner, daily briefing and SAST scan timetable.
- Close-based line chart with HH/HL/LH/LL swing annotations and 50 EMA overlay; candle display is an optional visual mode.
- CSV OHLC importer restricted to the five approved timeframes.
- Local strategy analysis using imported candles; no synthetic prices or fabricated alerts are generated.
- Cloudflare Worker + D1 backend for scheduled provider ingestion, strategy analysis, scan history, candle history, audit records and close-confirmed signals.
- Personal profile, selected instrument focus, session preferences, personalised notification settings and optional grade-specific in-app chime.
- Local trade journal with compressed screenshots, CSV export and full JSON backup/restore.
- Personal feedback summaries and rules-based performance observations. This is not a connected generative-AI model or machine-learning service.
- Generic position-size and reward/risk calculator.
- Legacy simplified backtest panel. It is not a validated backtest of the complete personal five-timeframe A+/A++ methodology.
- Optional TradingView Pine Script close-confirmed 1H event relay. The Pine file is a starter integration and has not been compiled/verified in a live TradingView account.
- GitHub Actions workflow for publishing the static PWA to GitHub Pages.

## Market-data status and important limitation

**No market-data provider is enabled in the packaged build.** The frontend can analyse user-imported OHLC files immediately. Cloud scanning becomes available only after the Worker/D1 service is deployed and a provider is confirmed to offer all required symbols, intervals, intended internal display rights and sufficient request capacity.

The Worker contains a Twelve Data adapter, but its feature gates default to `false`. Do not switch them on merely because an API key exists. Twelve Data's Basic/free offering is not confirmed as suitable for displaying all six requested instruments: its published Basic plan restricts use to internal/non-display applications and does not include commodity coverage for Gold/Silver. A separate plan/provider entitlement must be independently verified before the gates are enabled. See [docs/MARKET_DATA.md](docs/MARKET_DATA.md) for the provider comparison and acceptance checklist; always recheck current terms before configuring.

When a feed is connected, ATLAS stores provider candles and reports source/timestamps. It must not label delayed, historical, imported or synthetic values as live. No synthetic demo market prices are included.

## Cloudflare limits and storage design

The Worker and D1 configuration is intended to fit within Cloudflare's Free plan only if actual execution and daily usage remain within current quotas. At the time this project was prepared, Cloudflare's published D1 Free allowance includes 5 million rows read/day, 100,000 rows written/day and 5 GB total account storage; each individual D1 database is limited to 500 MB. Workers Free also has a 100,000 requests/day quota and a 10 ms CPU limit per invocation. These limits and plan terms can change; verify current official [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/), [D1 limits](https://developers.cloudflare.com/d1/platform/limits/) and [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/) before deployment.

The backend retains approximately 180 days of candle records and a rolling 1,000 scan/signal/audit records. Unique candle keys prevent repeated storage of identical bars. Monitor actual D1 size and Worker CPU in Cloudflare Analytics. The local Node benchmark is not a substitute for measuring deployed Worker CPU. If CPU exceeds the Free limit, the analysis must be optimised or divided into smaller work; do not assume free execution will work without checking.

## Data storage and privacy

- Imported OHLC candles and trade screenshots use browser IndexedDB where available. Smaller workspace settings, journal metadata and feedback use browser local storage.
- The local workspace does not automatically synchronise between devices. Export an ATLAS JSON backup and keep it private.
- The Worker API token and webhook secret are kept in the current browser session storage, not in the exported workspace backup.
- Market candles, signal events and scan results are stored remotely in Cloudflare D1 only after the user deploys and configures it.
- API keys belong in encrypted Worker secrets, never in `app.js`, `index.html`, GitHub Pages or a committed config file.

## What is not included / not guaranteed

- No broker integration, order execution, broker account credentials or automated trading.
- No authorised live-data feed is configured in this package.
- No guaranteed browser background execution or push notifications. The foreground PWA can poll the Worker while open; mobile operating systems may suspend background tabs. A separate push notification service would be needed for dependable push delivery.
- No connected economic calendar/news feed.
- No external AI model. Personal insight summaries are rules-based and reflect user-entered records.
- No promise that the strategy is profitable. The backtest panel does not fully model spread, commission, swap, slippage, latency or each broker's contract specifications.
- No verification of the Pine Script against TradingView's live compiler/account in this build.

## Project layout

```text
ATLAS_2_1/
├── index.html
├── styles.css
├── app.js
├── strategy-engine.js          # shared close-based multi-timeframe engine
├── manifest.webmanifest
├── sw.js
├── assets/                      # app icons
├── backend/
│   ├── worker.js                # Cloudflare Worker API, Cron and data adapter
│   ├── schema.sql               # D1 schema and indexes
│   ├── wrangler.toml            # Cron, D1 binding and fail-closed provider flags
│   ├── ATLAS_Opportunity_Bridge.pine
│   └── example-webhook.json
├── tests/                       # Node engine tests
├── docs/DEPLOYMENT.md
├── docs/MARKET_DATA.md
├── QUICKSTART.txt
└── .github/workflows/deploy-pages.yml
```

## Development checks

Node.js 20+ is recommended for the test scripts.

```bash
npm test
npm run check
```

The application is a static site and does not require a frontend build step. For deployment walkthroughs, use `docs/DEPLOYMENT.md` as the technical checklist; a separate step-by-step user walkthrough can be done when requested.
