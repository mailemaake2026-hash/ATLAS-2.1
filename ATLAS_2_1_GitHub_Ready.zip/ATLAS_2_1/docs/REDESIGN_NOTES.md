# ATLAS 2.1 — Command Deck redesign

This visual refresh gives the interface a distinct command-centre identity while preserving the existing strategy engine and application behavior.

## Design direction
- Graphite / deep-green surfaces with signal-lime as the primary brand accent.
- Stronger information hierarchy, monospaced operational labels and sharper panel geometry.
- A five-stage method rail makes the 1D → 4H → 2H → 1H → 30M model visible on the overview screen.
- Clearer separation between market context, structural confirmation and the user's final decision.
- Mobile layouts remain first-class, including a horizontally scrollable method rail and scanner data table.

## What changed
- Reworked the overview hero and copy around evidence-led market decisions.
- Re-styled navigation, status indicators, cards, tables, controls, strategy pills and panels.
- Updated the brand mark, PWA theme colors and service-worker cache version.
- Updated visible build identity to ATLAS 2.1 Command Edition / 2.1.1 visual refresh.

## What did not change
- Strategy-engine logic, timeframe restrictions, signal grading, risk calculations, local storage behavior, backend behavior and API contracts.
- No new live market-data source, AI model, broker integration or push-notification service is claimed by this visual refresh.

## Deployment note
After publishing, refresh the site once. If the old interface remains cached on Android, close all ATLAS tabs, reopen the site, or clear the site cache in browser settings. The service-worker cache namespace has been incremented to `atlas-pwa-v2.1.1-command-deck`.
