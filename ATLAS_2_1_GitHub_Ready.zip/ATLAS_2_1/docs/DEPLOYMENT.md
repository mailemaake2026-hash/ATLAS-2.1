# ATLAS 2.1 — deployment and cloud architecture checklist

This file is a technical deployment reference, not a click-by-click tutorial. A guided walkthrough can be provided separately when requested.

## 1. GitHub Pages frontend

The repository root must contain `index.html`, `styles.css`, `app.js`, `strategy-engine.js`, `manifest.webmanifest`, `sw.js`, `assets/` and `.github/workflows/deploy-pages.yml`. Publish the repository using the included GitHub Actions Pages workflow. The application has no frontend build step. The frontend needs HTTPS for the PWA service worker and browser notifications.

The Worker CORS `ALLOWED_ORIGIN` must be the site's exact origin, e.g. `https://USERNAME.github.io`. For a GitHub project site, the origin does not include `/REPOSITORY`.

## 2. Cloudflare D1

Create a D1 database and execute `backend/schema.sql` once. Insert its database ID in `backend/wrangler.toml`, replacing `REPLACE_WITH_YOUR_D1_DATABASE_ID`. The schema includes:

- `market_candles`: unique instrument/timeframe/candle timestamp rows.
- `scan_runs`: stored per-symbol analysis results for each scheduled run.
- `signals`: deduplicated confirmed structure events and optional inbound webhook events.
- `scan_audit`: completed, skipped and failed scan records.

The Worker rejects scans if the most recent completed 30M candle is more than 90 minutes old, or the most recent completed daily candle is more than 72 hours old. It retains approximately 180 days of market candles and the most recent 1,000 scan, signal and audit rows. These are retention safeguards, not guarantees of a particular database size. Inspect D1 storage and query consumption after deployment.

Cloudflare's published Free D1 plan at preparation time lists 5 million rows read/day, 100,000 rows written/day and 5 GB total storage across the account; a single D1 database is limited to 500 MB. Confirm current [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/) and [D1 limits](https://developers.cloudflare.com/d1/platform/limits/). If free-tier quotas are exceeded, queries/writes can fail until the quota resets or the storage issue is addressed.

## 3. Cloudflare Worker

The Worker source is `backend/worker.js`, with shared strategy logic imported from `../strategy-engine.js`. Deploy using Wrangler with the config file from the project root so the shared import resolves:

```bash
npx wrangler deploy --config backend/wrangler.toml
```

Set the following encrypted Worker secrets using unique random values:

- `ATLAS_API_TOKEN` — protects private ATLAS API reads and manual scans.
- `ATLAS_WEBHOOK_SECRET` — protects the optional `/tv/<secret>` webhook route.
- `TWELVE_DATA_API_KEY` — only if a provider plan has been validated for all required instruments, history and intended use.

Set `ALLOWED_ORIGIN` as a Worker variable to the exact frontend origin. The config's provider permission flags default to `false`:

- `TWELVE_DATA_DISPLAY_RIGHTS_CONFIRMED`
- `TWELVE_DATA_METALS_ACCESS_CONFIRMED`

Do not change either flag to `true` until the actual provider contract/account permits the intended internal app display and the required Gold and Silver instruments. Merely possessing an API key does not establish those rights or coverage.

### Current provider adapter limitation

The code includes a Twelve Data `time_series` adapter for six instruments, but the Twelve Data Basic/free plan should not be treated as a usable default for this application: published Basic terms describe internal/non-display use and do not include the commodity coverage needed for XAUUSD and XAGUSD. Verify current [individual plans](https://twelvedata.com/pricing) and [business plans](https://twelvedata.com/pricing), including symbol entitlement, intraday history, display rights and request limits. The adapter fails closed until both permission flags are explicitly enabled. No provider is connected in this package.

A suitable alternative feed may be added later through the provider adapter pattern. See [MARKET_DATA.md](MARKET_DATA.md) for the provider comparison and acceptance checklist. Check its terms, Gold/Silver coverage, all six pairs, historical depth, 30-minute interval availability, rate limits and intended app display rights before enabling it. Do not label delayed or imported candles as live.

## 4. Cron schedule and execution limits

The included Worker Cron Triggers are UTC expressions corresponding to SAST (UTC+2):

- 08:00 SAST (quiet window; once per 2-hour window).
- 10:00 and 11:30 SAST (normal window; every 90 minutes).
- 12:00 through 19:00 SAST (high-activity window; hourly).
- No overnight or weekend schedule.

The Worker independently checks the SAST schedule before manual or scheduled full scanning. The selected schedule is clock-based; it does not fetch a separate volatility feed or public-holiday calendar.

Cloudflare Workers Free has a documented 100,000 request/day limit and 10 ms CPU per invocation at the time of preparation. The code is intentionally lean, but local Node timing does not prove deployed Cloudflare CPU usage. Measure deployed CPU in Cloudflare Analytics; reduce work or split processing if the actual invocation exceeds the Free CPU allowance. See [Workers pricing and limits](https://developers.cloudflare.com/workers/platform/pricing/).

## 5. ATLAS app connection

After the Worker and D1 are deployed, the ATLAS **Cloud connection** screen accepts:

- Worker base URL.
- `ATLAS_API_TOKEN`.
- `ATLAS_WEBHOOK_SECRET` for the generated optional TradingView URL.

The API token and webhook secret are stored in the current browser session, not exported in the workspace backup. The app calls authenticated endpoints for scan results, candle history and signals. The Worker API does not expose the Twelve Data key to the browser.

## 6. API endpoints

| Endpoint | Method | Authentication | Purpose |
|---|---|---|---|
| `/api/health` | GET | Public health status | D1 connectivity and provider gate status |
| `/api/candles?symbol=XAUUSD&timeframe=30M` | GET | Bearer token | Stored candles for 30M or 1D; higher frames are aggregated client/server-side |
| `/api/scans` | GET | Bearer token | Recent cloud analysis results |
| `/api/signals` | GET | Bearer token | Recent confirmed structure/inbound signal events |
| `/api/scan` | POST | Bearer token | Manual scan, subject to time window and provider gates |
| `/api/audit` | GET | Bearer token | Recent scan audit trail |
| `/tv/<webhook-secret>` | POST | Secret URL path | Optional validated TradingView event ingestion |

## 7. Optional TradingView relay

`backend/ATLAS_Opportunity_Bridge.pine` is a starter 1H close-confirmed relay. It uses close-based pivots and alerts only when the completed 1H candle closes beyond the latest confirmed structural level. It does not grade the five-timeframe A+/A++ strategy or judge the candle's validity. It has not been compiled in TradingView's Pine Editor in this build; validate it in the user's TradingView account before relying on it. TradingView controls webhook/alert eligibility and may require an eligible account plan.

## 8. Notifications and background behaviour

When the PWA is open and foregrounded, it can poll the Worker for new results/signals and show browser notifications if the user grants permission. The in-app chime is optional. This build does not implement Web Push and cannot guarantee delivery while Android/browser suspends the app. Server-side Cron can continue scanning after deployment, but user-device push delivery requires a separate push service and subscription flow that are not included.

## 9. Verification checklist

- `npm test` passes for the strategy engine and Worker API security/gating tests.
- `npm run check` passes JavaScript syntax checks.
- D1 health endpoint reports connected after schema and binding setup.
- Private API endpoints reject missing/incorrect bearer tokens.
- CORS accepts only the configured GitHub Pages origin.
- Provider flags remain false until data terms and entitlement are checked.
- The Worker audit records skipped scans when the provider is not enabled.
- Deployed Worker CPU and D1 daily consumption are inspected after actual scans.
- The app displays source and timestamp metadata for connected candles.
- The TradingView Pine starter is separately validated before optional activation.
