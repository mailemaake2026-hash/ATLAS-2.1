# ATLAS 2.1 — Market-data provider decision

**Review date: 8 November 2026**

## Decision in this build

No market-data provider is enabled by default. This is deliberate: ATLAS needs a single, dependable feed (or a clearly documented multi-feed combination) that covers all six instruments, supplies the required OHLC history, and permits the intended private in-app display. A free API key alone is not enough to establish those conditions.

Required instruments:

- XAUUSD and XAGUSD
- EURUSD, GBPUSD, USDJPY and AUDUSD

Required source intervals:

- 30-minute OHLC, from which complete 1H, 2H and 4H bars can be aggregated
- Daily OHLC

ATLAS must timestamp each candle, state the source, identify delayed/historical status, and never present imported or stale prices as live. All candle times must be normalised consistently (preferably UTC) before aggregation and SAST session interpretation.

## Public-provider findings

### Twelve Data

Its current Basic plan is free and publishes 8 API credits/minute and 800 credits/day. The plan comparison describes Basic as internal non-display use and lists real-time Forex, but not the commodity coverage needed for Gold and Silver. Paid Grow includes commodities and internal display access, but exact symbols, intraday history and plan entitlements must be checked in the account before use. The Twelve Data adapter in `backend/worker.js` therefore fails closed unless the user explicitly confirms display rights and both metals entitlements. It is not enabled in this package.

Sources: [Twelve Data individual pricing](https://twelvedata.com/pricing).

### AlgoSpecial free OHLC preview

Its public API documents XAUUSD and major Forex coverage, with no key, a 60-request/minute and 1,000-request/day public limit, and a no-redistribution-as-a-standalone-service restriction. Its XAUUSD guide documents M30, H1, H4 and D1 data. However, the reviewed catalogue does not establish XAGUSD coverage. The API overview and rate-limits pages also disagree about preview range/row limits (2,000 rows/31 days on the overview versus 50,000 rows/366 days on the rate-limits page). Timestamps are broker-server time. This is a possible Gold/Forex research source, not a validated complete feed for ATLAS.

Sources: [API overview](https://www.algospecial.com/data-api/), [XAUUSD guide](https://www.algospecial.com/data-api/xauusd/), [Forex guide](https://www.algospecial.com/data-api/forex/), [rate limits](https://www.algospecial.com/data-api/rate-limits/).

### FCS API

Its FAQ advertises a free allowance of 500 API calls/month, commodities including Gold and Silver, 30-minute through daily OHLC history, and bulk requests for multiple Forex pairs. That headline quota needs careful modelling against ATLAS's 11 weekday scans and any separate requests required for metals, intraday and daily bars. The exact plan rights, endpoint support for XAUUSD/XAGUSD historical intervals, bulk-symbol behaviour and request-credit accounting must be verified before integration. At 500 calls/month, it must not be assumed to support the whole scanning schedule without a successful quota test.

Sources: [FCS API FAQ](https://fcsapi.com/faq), [FCS API documentation](https://fcsapi.com/documentation).

### Other public options

Some free metals APIs provide spot or daily history but no intraday candles; others provide indicative or delayed prices rather than a consistent broker-style OHLC series. Such feeds can be useful for reference but cannot silently replace the OHLC source used for line-chart structure and close-confirmation.

## Why the provider remains disabled

The existing Twelve Data adapter is a scaffold, not proof of a working free data connection. Enabling an unverified source could produce incomplete symbols, insufficient history, mismatched daily boundaries, unexpected API consumption or a display-licensing problem. Until a complete provider is validated, local CSV import is the only active data route in this package.

## Provider acceptance checklist

Before enabling a feed, confirm all of the following from the provider's current documentation and actual account:

1. All six required instruments resolve to the intended market and symbol type.
2. 30-minute and daily historical OHLC are both available for each instrument.
3. There is enough candle history to calculate confirmed close-based swings and the 50 EMA without falsely reporting insufficient alignment.
4. API quotas comfortably cover the 11 scheduled scans per weekday, initial history loading, retries and health checks.
5. The account permits the intended private display inside the ATLAS PWA and Cloudflare Worker.
6. Timestamp timezone, market session boundaries, missing bars and weekend gaps are documented and correctly normalised.
7. Rate limits, temporary errors, stale data and provider outages are handled without presenting old prices as fresh.
8. The Worker secret remains server-side; no provider API key is committed to GitHub or embedded in the browser application.

The system must fail closed when data is incomplete or provider rights are unverified. It must show the actual provider, last candle timestamp and data freshness. Do not bypass this gate simply to make a chart look populated.
