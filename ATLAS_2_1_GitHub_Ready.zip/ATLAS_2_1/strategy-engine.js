/* ATLAS 2.1 shared strategy engine. Close-based structure, non-repainting swing confirmation. */
export const TIMEFRAMES = [
  { id: '1D', label: 'Daily', minutes: 1440 },
  { id: '4H', label: '4-hour', minutes: 240 },
  { id: '2H', label: '2-hour', minutes: 120 },
  { id: '1H', label: '1-hour', minutes: 60 },
  { id: '30M', label: '30-minute', minutes: 30 }
];
export const EMA_PERIOD = 50;
export const SWING_STRENGTH_DEFAULT = 2;

export function ema(values, period = EMA_PERIOD) {
  const out = Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let value = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = value;
  for (let i = period; i < values.length; i++) {
    value = values[i] * k + value * (1 - k);
    out[i] = value;
  }
  return out;
}

export function validBars(input) {
  return (Array.isArray(input) ? input : []).map((b) => ({
    time: b.time || b.datetime || b.timestamp || '',
    open: Number(b.open), high: Number(b.high), low: Number(b.low), close: Number(b.close),
    volume: Number(b.volume || 0)
  })).filter((b) => [b.open, b.high, b.low, b.close].every(Number.isFinite)
    && Number.isFinite(Date.parse(b.time))
    && b.high >= Math.max(b.open, b.close) && b.low <= Math.min(b.open, b.close))
    .sort((a, b) => Date.parse(a.time) - Date.parse(b.time))
    .filter((bar, index, all) => index === 0 || bar.time !== all[index - 1].time);
}

export function filterClosedBars(bars, now = Date.now(), minutes = 30) {
  const duration = minutes * 60_000;
  return validBars(bars).filter((b) => {
    const t = Date.parse(b.time);
    return Number.isFinite(t) && t + duration <= now;
  });
}

export function aggregateBars(input, targetMinutes, now = Date.now(), sourceMinutes = 30) {
  if (targetMinutes === sourceMinutes) return filterClosedBars(input, now, sourceMinutes);
  const bars = filterClosedBars(input, now, sourceMinutes);
  const buckets = new Map();
  const targetMs = targetMinutes * 60_000;
  const expectedBars = targetMinutes / sourceMinutes;
  if (!Number.isInteger(expectedBars) || expectedBars < 1) return [];
  for (const b of bars) {
    const t = Date.parse(b.time);
    const bucket = Math.floor(t / targetMs) * targetMs;
    const item = buckets.get(bucket);
    if (!item) buckets.set(bucket, { time: new Date(bucket).toISOString(), open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume || 0, count: 1 });
    else {
      item.high = Math.max(item.high, b.high);
      item.low = Math.min(item.low, b.low);
      item.close = b.close;
      item.volume += b.volume || 0;
      item.count++;
    }
  }
  return [...buckets.entries()].sort((a, b) => a[0] - b[0])
    // Keep only complete bars. A partial 1H/2H/4H aggregate would distort
    // both line-chart structure and the close-confirmation rule.
    .filter(([bucket, bar]) => bucket + targetMs <= now && bar.count === expectedBars)
    .map(([, b]) => ({ time: b.time, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume }));
}

function detectSwingsFromValidBars(bars, strength = SWING_STRENGTH_DEFAULT) {
  const highs = [], lows = [];
  for (let i = strength; i < bars.length - strength; i++) {
    const value = bars[i].close;
    let isHigh = true, isLow = true;
    for (let j = i - strength; j <= i + strength; j++) {
      if (j === i) continue;
      if (bars[j].close >= value) isHigh = false;
      if (bars[j].close <= value) isLow = false;
      if (!isHigh && !isLow) break;
    }
    // A pivot is available only after the right-side candles have closed.
    if (isHigh) highs.push({ index: i, time: bars[i].time, price: value });
    if (isLow) lows.push({ index: i, time: bars[i].time, price: value });
  }
  return { highs, lows };
}
export function detectSwings(input, strength = SWING_STRENGTH_DEFAULT) {
  return detectSwingsFromValidBars(validBars(input), strength);
}

export function describeTrend(swings) {
  const hs = swings.highs.slice(-2), ls = swings.lows.slice(-2);
  if (hs.length === 2 && ls.length === 2) {
    const higherHigh = hs[1].price > hs[0].price;
    const higherLow = ls[1].price > ls[0].price;
    const lowerHigh = hs[1].price < hs[0].price;
    const lowerLow = ls[1].price < ls[0].price;
    if (higherHigh && higherLow) return 'BULLISH';
    if (lowerHigh && lowerLow) return 'BEARISH';
  }
  // EMA is a separate, optional confirmation. It must never manufacture
  // directional alignment when the close-based swing structure is unclear.
  return 'NEUTRAL';
}

function findLatestConfirmedBreakFromValidBars(bars, strength = SWING_STRENGTH_DEFAULT, lookback = 3) {
  if (bars.length < strength * 2 + 8) return null;
  const from = Math.max(strength * 2 + 3, bars.length - lookback);
  for (let i = bars.length - 1; i >= from; i--) {
    const prefix = bars.slice(0, i); // only candles closed before the candidate may define the level
    const swings = detectSwingsFromValidBars(prefix, strength);
    const prev = bars[i - 1], current = bars[i];
    const range = detectAccumulation(prefix);
    // While a range is active, ignore internal swings. Only a confirmed close
    // outside the full close-based range can become a structure event.
    const highLevel = range.active ? range.high : swings.highs.at(-1)?.price;
    const lowLevel = range.active ? range.low : swings.lows.at(-1)?.price;
    const rangeBreak = Boolean(range.active);
    if (highLevel != null && prev.close <= highLevel && current.close > highLevel) {
      return { direction: 'LONG', type: rangeBreak ? 'ACCUMULATION_RANGE_BREAK_UP' : 'BULLISH_STRUCTURE_BREAK', level: highLevel, candleTime: current.time, candleClose: current.close, previousClose: prev.close, candleIndex: i, rangeBreak, rangeHigh: rangeBreak ? range.high : null, rangeLow: rangeBreak ? range.low : null, confirmation: 'CLOSED_CANDLE_ABOVE_LEVEL' };
    }
    if (lowLevel != null && prev.close >= lowLevel && current.close < lowLevel) {
      return { direction: 'SHORT', type: rangeBreak ? 'ACCUMULATION_RANGE_BREAK_DOWN' : 'BEARISH_STRUCTURE_BREAK', level: lowLevel, candleTime: current.time, candleClose: current.close, previousClose: prev.close, candleIndex: i, rangeBreak, rangeHigh: rangeBreak ? range.high : null, rangeLow: rangeBreak ? range.low : null, confirmation: 'CLOSED_CANDLE_BELOW_LEVEL' };
    }
  }
  return null;
}

export function findLatestConfirmedBreak(input, strength = SWING_STRENGTH_DEFAULT, lookback = 3) {
  return findLatestConfirmedBreakFromValidBars(validBars(input), strength, lookback);
}

function averageTrueRange(bars, period = 14) {
  if (bars.length < period + 1) return null;
  const trs = [];
  for (let i = 1; i < bars.length; i++) {
    const b = bars[i], prev = bars[i - 1];
    trs.push(Math.max(b.high - b.low, Math.abs(b.high - prev.close), Math.abs(b.low - prev.close)));
  }
  const tail = trs.slice(-period);
  return tail.reduce((a, b) => a + b, 0) / tail.length;
}

export function detectAccumulation(bars, lookback = 12) {
  if (bars.length < lookback + 15) return { active: false, high: null, low: null, widthToAtr: null };
  const window = bars.slice(-lookback);
  const closes = window.map((b) => b.close);
  const high = Math.max(...closes), low = Math.min(...closes);
  const atrValue = averageTrueRange(bars, 14);
  const widthToAtr = atrValue ? (high - low) / atrValue : null;
  return { active: widthToAtr != null && widthToAtr <= 3.5, high, low, widthToAtr };
}

function analyzeValidTimeframeBars(bars, timeframe, strength) {
  if (bars.length < 60) return { timeframe, ready: false, bars: bars.length, direction: 'INSUFFICIENT_DATA', ema50: null, emaConfirmed: false, swings: { highs: [], lows: [] }, latestClose: bars.at(-1)?.close ?? null };
  const closes = bars.map((b) => b.close);
  const emaSeries = ema(closes, EMA_PERIOD);
  const ema50 = emaSeries.at(-1);
  const swings = detectSwingsFromValidBars(bars, strength);
  const direction = describeTrend(swings);
  return {
    timeframe, ready: true, bars: bars.length, direction, latestClose: closes.at(-1),
    previousClose: closes.at(-2), ema50, emaConfirmed: null,
    swings: { highs: swings.highs.slice(-4), lows: swings.lows.slice(-4) },
    lastSwingHigh: swings.highs.at(-1) || null, lastSwingLow: swings.lows.at(-1) || null,
    accumulation: detectAccumulation(bars)
  };
}
export function analyzeTimeframe(input, timeframe, options = {}) {
  const bars = validBars(input);
  const strength = Math.max(2, Math.min(5, Number(options.swingStrength || SWING_STRENGTH_DEFAULT)));
  return analyzeValidTimeframeBars(bars, timeframe, strength);
}

export function gradeSetup(alignmentCount, structuralBreak, ema1hConfirmed) {
  const hasBreak = Boolean(structuralBreak);
  if (alignmentCount === 5 && hasBreak) return ema1hConfirmed ? 'A++' : 'A+';
  if (alignmentCount >= 4 && hasBreak) return 'A';
  if (alignmentCount >= 3 && hasBreak) return 'B+';
  if (alignmentCount >= 4) return 'B+';
  if (alignmentCount >= 3) return 'B';
  if (alignmentCount >= 2 && hasBreak) return 'C+';
  return 'C';
}

export function analyzeSymbol(symbol, datasets, options = {}) {
  const strength = Math.max(2, Math.min(5, Number(options.swingStrength || SWING_STRENGTH_DEFAULT)));
  const cleanDatasets = {};
  const frames = {};
  for (const tf of TIMEFRAMES) {
    cleanDatasets[tf.id] = validBars(datasets[tf.id] || []);
    frames[tf.id] = analyzeValidTimeframeBars(cleanDatasets[tf.id], tf.id, strength);
  }
  const oneHourBars = cleanDatasets['1H'];
  const oneHour = frames['1H'];
  const structuralBreak = oneHour.ready ? findLatestConfirmedBreakFromValidBars(oneHourBars, strength, options.breakLookback || 3) : null;
  const direction = structuralBreak?.direction || (oneHour.direction === 'BULLISH' ? 'LONG' : oneHour.direction === 'BEARISH' ? 'SHORT' : null);
  // A confirmed 1H close-break represents the structure shift on that entry
  // timeframe. Other timeframes must still independently show HH/HL or LH/LL.
  const alignedFrames = direction ? TIMEFRAMES.filter((tf) => {
    if (tf.id === '1H' && structuralBreak?.direction === direction) return true;
    const d = frames[tf.id].direction;
    return direction === 'LONG' ? d === 'BULLISH' : d === 'BEARISH';
  }).map((tf) => tf.id) : [];
  const alignmentCount = alignedFrames.length;
  const emaConfirmations = TIMEFRAMES.filter((tf) => {
    const frame = frames[tf.id];
    return frame.ready && (direction === 'LONG' ? frame.latestClose > frame.ema50 : direction === 'SHORT' ? frame.latestClose < frame.ema50 : false);
  }).map((tf) => tf.id);
  const ema1hConfirmed = emaConfirmations.includes('1H');
  const grade = direction ? gradeSetup(alignmentCount, structuralBreak && structuralBreak.direction === direction, ema1hConfirmed) : 'C';
  const range = oneHourBars.length ? detectAccumulation(oneHourBars) : { active: false };
  const latest = oneHourBars.at(-1) || null;
  const isConfirmedOneHourBreak = Boolean(structuralBreak && latest && structuralBreak.direction === direction);
  const reasons = [];
  if (alignmentCount === 5) reasons.push('All five approved timeframes align.');
  else reasons.push(`${alignmentCount}/5 approved timeframes align.`);
  if (structuralBreak) reasons.push(`${structuralBreak.type.replaceAll('_', ' ').toLowerCase()} confirmed by a closed 1H candle.`);
  else reasons.push('No new confirmed 1H structural close-break detected in the latest scan window.');
  if (ema1hConfirmed) reasons.push('1H 50 EMA (Close) confirms the direction: A++ enhancement.');
  else if (emaConfirmations.length) reasons.push(`EMA confirmation present on ${emaConfirmations.join(', ')}, but only 1H EMA can upgrade A+ to A++.`);
  else reasons.push('50 EMA (Close) does not currently confirm; EMA is optional.');
  if (range.active && !structuralBreak) reasons.push('1H accumulation/range detected; no entry-grade alert is produced while price remains inside it.');
  if (structuralBreak?.rangeBreak) reasons.push('A completed 1H candle closed outside the previously detected accumulation range.');
  return {
    symbol, direction, grade, alignmentCount, alignedFrames, emaConfirmations, ema1hConfirmed,
    structuralBreak, confirmedOneHourBreak: isConfirmedOneHourBreak,
    entryEligible: Boolean(isConfirmedOneHourBreak), watchOnly: Boolean(range.active && !isConfirmedOneHourBreak),
    accumulation: range.active, range, frames, price: latest?.close ?? null,
    candleTime: latest?.time ?? null, dataMode: options.dataMode || 'IMPORTED',
    ready: TIMEFRAMES.every((tf) => frames[tf.id].ready), reasons
  };
}

export function getSastSchedule(date = new Date()) {
  const fmt = new Intl.DateTimeFormat('en-GB', { timeZone: 'Africa/Johannesburg', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
  const [hour, minute] = fmt.format(date).split(':').map(Number);
  const minutes = hour * 60 + minute;
  const day = new Intl.DateTimeFormat('en-US', { timeZone: 'Africa/Johannesburg', weekday: 'short' }).format(date);
  const weekday = !['Sat', 'Sun'].includes(day);
  let condition = 'MAJOR_CLOSURE', frequencyMinutes = 0, label = 'Major market closure', nextTimes = [];
  if (weekday && minutes >= 480 && minutes < 600) { condition = 'QUIET'; frequencyMinutes = 120; label = 'Quiet market conditions'; }
  else if (weekday && minutes >= 600 && minutes < 720) { condition = 'NORMAL'; frequencyMinutes = 90; label = 'Normal market activity'; }
  else if (weekday && minutes >= 720 && minutes < 1200) { condition = 'HIGH'; frequencyMinutes = 60; label = 'High market activity'; }
  const schedule = ['08:00', '10:00', '11:30', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'];
  const next = weekday && minutes < 1200
    ? (minutes < 480 ? '08:00' : schedule.find((value) => { const [h, m] = value.split(':').map(Number); return h * 60 + m > minutes; }) || 'Next weekday 08:00')
    : 'Next weekday 08:00';
  const currentScanTimes = condition === 'QUIET' ? ['08:00'] : condition === 'NORMAL' ? ['10:00', '11:30'] : condition === 'HIGH' ? schedule.filter((x) => Number(x.slice(0, 2)) >= 12) : [];
  return { condition, frequencyMinutes, label, weekday, sast: fmt.format(date), nextScan: next, currentScanTimes };
}
