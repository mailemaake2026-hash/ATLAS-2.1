const CACHE = 'atlas-pwa-v2.1.1-command-deck';
const CORE = [
  './', './index.html', './styles.css', './app.js', './strategy-engine.js', './manifest.webmanifest',
  './assets/atlas-mark.svg', './assets/atlas-192.png', './assets/atlas-512.png', './assets/apple-touch-icon.png', './docs/DEPLOYMENT.md', './docs/MARKET_DATA.md'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(req).then(cached => {
    if (cached) return cached;
    return fetch(req).then(response => {
      if (response && response.ok) {
        const copy = response.clone();
        caches.open(CACHE).then(cache => cache.put(req, copy));
      }
      return response;
    }).catch(() => caches.match('./index.html'));
  }));
});
